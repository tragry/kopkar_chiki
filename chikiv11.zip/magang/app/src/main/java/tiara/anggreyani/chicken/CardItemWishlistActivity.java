package tiara.anggreyani.chicken;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CardItemWishlistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_item_wishlist);
    }
}