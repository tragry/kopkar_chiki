package tiara.anggreyani.chicken.Model.Plafon;

public class Plafon{
	private TotalPlafon total_plafon;
	private SisaPlafon sisa_plafon;

	public TotalPlafon getTotalPlafon(){
		return total_plafon;
	}

	public SisaPlafon getSisaPlafon(){
		return sisa_plafon;
	}
}
