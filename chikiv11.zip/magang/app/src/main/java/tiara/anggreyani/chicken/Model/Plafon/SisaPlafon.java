package tiara.anggreyani.chicken.Model.Plafon;

public class SisaPlafon{
	private int special;
	private int reguler;

	public int getSpecial(){
		return special;
	}

	public int getReguler(){
		return reguler;
	}
}
