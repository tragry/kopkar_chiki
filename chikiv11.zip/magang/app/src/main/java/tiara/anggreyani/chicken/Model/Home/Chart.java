package tiara.anggreyani.chicken.Model.Home;

public class Chart{
	private int pinjaman;
	private int simpanan;
	private int plafon;

	public int getPinjaman(){
		return pinjaman;
	}

	public int getSimpanan(){
		return simpanan;
	}

	public int getPlafon(){
		return plafon;
	}
}
