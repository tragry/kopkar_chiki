package tiara.anggreyani.chicken.Model.Profile;

public class StatusKawin{
	private int jumlahAnak;
	private String status;

	public int getJumlahAnak(){
		return jumlahAnak;
	}

	public String getStatus(){
		return status;
	}
}
