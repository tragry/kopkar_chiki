package tiara.anggreyani.chicken.Model.Home;

public class Data{
	private Detail detail;
	private Chart chart;

	public Detail getDetail(){
		return detail;
	}

	public Chart getChart(){
		return chart;
	}
}
