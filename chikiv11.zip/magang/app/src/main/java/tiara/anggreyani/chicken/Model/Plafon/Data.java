package tiara.anggreyani.chicken.Model.Plafon;

public class Data{
	private Anggota anggota;
	private Plafon plafon;

	public Anggota getAnggota(){
		return anggota;
	}

	public Plafon getPlafon(){
		return plafon;
	}
}
