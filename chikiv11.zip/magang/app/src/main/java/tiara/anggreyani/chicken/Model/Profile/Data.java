package tiara.anggreyani.chicken.Model.Profile;

public class Data{
	private String no_hp;
	private String no_karyawan;
	private String jabatan;
	private String alamat;
	private String departemen;
	private StatusKawin status_perkawinan;
	private String tempat_lahir;
	private String no_ktp;
	private String grade;
	private String name;
	private String gender;
	private String tgl_lahir;
	private Plafon plafon;

	public String getNoHp(){
		return no_hp;
	}

	public String getNoKaryawan(){
		return no_karyawan;
	}

	public String getJabatan(){
		return jabatan;
	}

	public String getAlamat(){
		return alamat;
	}

	public String getDepartemen(){
		return departemen;
	}

	public StatusKawin getStatusKawin(){
		return status_perkawinan;
	}

	public String getTempatLahir(){
		return tempat_lahir;
	}

	public String getNoKtp(){
		return no_ktp;
	}

	public String getGrade(){
		return grade;
	}

	public String getName(){
		return name;
	}

	public String getJenisKelamin(){
		return gender;
	}

	public String getTanggalLahir(){
		return tgl_lahir;
	}

	public Plafon getPlafon(){
		return plafon;
	}
}
