package tiara.anggreyani.chicken.Model.Plafon;

public class TotalPlafon{
	private int total;
	private int plafon_reguler;
	private String plafon_special;

	public int getTotal(){
		return total;
	}

	public int getPlafonReguler(){
		return plafon_reguler;
	}

	public String getPlafonSpecial(){
		return plafon_special;
	}
}
