package tiara.anggreyani.chicken.Model.Simpanan;

public class ResponseItem{
	private String akunDebit;
	private String keterangan;
	private String code;
	private String nilai;
	private String jenisPotongan;
	private String createdAt;
	private String akunKreditT;
	private String bunga;
	private String rubahNilai;
	private String updatedAt;
	private String name;
	private int id;
	private String akunKreditC;

	public String getAkunDebit(){
		return akunDebit;
	}

	public String getKeterangan(){
		return keterangan;
	}

	public String getCode(){
		return code;
	}

	public String getNilai(){
		return nilai;
	}

	public String getJenisPotongan(){
		return jenisPotongan;
	}

	public String getCreatedAt(){
		return createdAt;
	}

	public String getAkunKreditT(){
		return akunKreditT;
	}

	public String getBunga(){
		return bunga;
	}

	public String getRubahNilai(){
		return rubahNilai;
	}

	public String getUpdatedAt(){
		return updatedAt;
	}

	public String getName(){
		return name;
	}

	public int getId(){
		return id;
	}

	public String getAkunKreditC(){
		return akunKreditC;
	}
}
