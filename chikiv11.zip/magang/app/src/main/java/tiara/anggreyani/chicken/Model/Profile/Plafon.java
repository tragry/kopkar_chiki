package tiara.anggreyani.chicken.Model.Profile;

public class Plafon{
	private int reguler;

	public int getReguler(){
		return reguler;
	}
}
