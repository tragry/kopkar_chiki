package tiara.anggreyani.chicken.Model.Plafon;

public class Anggota{
	private String userId;
	private String noKaryawan;
	private String jabatan;
	private String name;
	private int id;

	public String getUserId(){
		return userId;
	}

	public String getNoKaryawan(){
		return noKaryawan;
	}

	public String getJabatan(){
		return jabatan;
	}

	public String getName(){
		return name;
	}

	public int getId(){
		return id;
	}
}
