package tiara.anggreyani.chicken;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MenuPopupActivity extends AppCompatActivity {

    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;

    ImageView pinjamanUang, pinjamanKaryawan, pengajuanPinjaman,
              penarikanSimpanan, perubahanSimpanan, wishlistMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_popup);

        pinjamanUang = findViewById(R.id.pinjaman_uang);
        pinjamanKaryawan = findViewById(R.id.pinjaman_karyawan);
        pengajuanPinjaman = findViewById(R.id.pengajuan_pinjaman);
        penarikanSimpanan = findViewById(R.id.penarikan_simpanan);
        perubahanSimpanan = findViewById(R.id.perubahan_simpanan);
        wishlistMenu= findViewById(R.id.wishlist);

        /*pinjamanUang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MenuPopupActivity.this, PinjamanUangActivity.class));
            }
        });*/
        pinjamanKaryawan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MenuPopupActivity.this, WishlistActivity.class));
            }
        });
        pengajuanPinjaman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MenuPopupActivity.this, PengajuanPinjamanActivity.class));
            }
        });
        penarikanSimpanan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MenuPopupActivity.this, PenarikanSimpananActivity.class));
            }
        });
        perubahanSimpanan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MenuPopupActivity.this, PerubahanSimpananActivity.class));
            }
        });

        wishlistMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MenuPopupActivity.this, WishlistActivity.class));
            }
        });
    }
}