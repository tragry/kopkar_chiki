package tiara.anggreyani.chicken.Model.Plafon;

public class PlafonResponse {
	private int pinjaman2;
	private int total_nilai_plafon;
	private int sisa_plafon1;
	private int sisa_plafon2;
	private int pinjaman1;
	private String nilai_plafon2;
	private String nilai_plafon1;
	private String status;

	public int getPinjaman2(){
		return pinjaman2;
	}

	public int getTotal_nilai_plafon(){
		return total_nilai_plafon;
	}

	public int getSisa_plafon1(){
		return sisa_plafon1;
	}

	public int getSisa_plafon2(){
		return sisa_plafon2;
	}

	public int getPinjaman1(){
		return pinjaman1;
	}

	public String getNilai_plafon2(){
		return nilai_plafon2;
	}

	public String getNilai_plafon1(){ return nilai_plafon1;
	}

	public String getStatus(){
		return status;
	}
}
