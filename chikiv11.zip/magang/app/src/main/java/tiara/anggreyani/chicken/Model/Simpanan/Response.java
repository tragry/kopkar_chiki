package tiara.anggreyani.chicken.Model.Simpanan;

import java.util.List;

public class Response{
	private List<ResponseItem> response;

	public List<ResponseItem> getResponse(){
		return response;
	}
}