package tiara.anggreyani.chicken;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SimpananPopupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simpanan_popup);

    }
}